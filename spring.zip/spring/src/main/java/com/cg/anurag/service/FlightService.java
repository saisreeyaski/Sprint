package com.cg.anurag.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.anurag.dao.FlightDAO;
import com.cg.anurag.dto.Flight;

@Service
public class FlightService 
{
	@Autowired
    FlightDAO fdao;
    public void setFdao( FlightDAO fdao) 
    { 
    	this.fdao=fdao;
    	} 
    
    @Transactional(readOnly = true)
	public Flight getFlightBySourceAirport(String source_airport)
    {
    	return fdao.getFlightBySourceAirport(source_airport);
    }

}