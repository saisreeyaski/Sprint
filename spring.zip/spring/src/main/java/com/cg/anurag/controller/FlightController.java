package com.cg.anurag.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.anurag.dto.Flight;
import com.cg.anurag.service.FlightService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class FlightController {

	@Autowired
	FlightService flightService;
	public void setFlightService(FlightService flightService)
	{
		this.flightService=flightService;
	}
	
	 @GetMapping(value="/getFlights/{sourceAirport}")
	 public Flight getFlights(String source_airport)
	   {
		return flightService.getFlightBySourceAirport(source_airport);
	   }
}