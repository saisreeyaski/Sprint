package com.cg.anurag.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.anurag.dao.ScheduledflightDAO;
import com.cg.anurag.dto.Scheduledflight;

@Service
public class ScheduledflightService {
	@Autowired
    ScheduledflightDAO sdao;
    public void setSdao( ScheduledflightDAO sdao) 
    { 
    	this.sdao=sdao;
    	} 
	
	@Transactional(readOnly=true)
    public List<Scheduledflight> getScheduledflight()
    {
    	return sdao.findAll();
    }

	}
