package com.cg.anurag.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.anurag.dto.Flight;
@Repository
public interface FlightDAO extends JpaRepository<Flight,Integer> 
{
	public Flight getFlightBySourceAirport(String sourceAirport);
}