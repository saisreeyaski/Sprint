package com.cg.anurag.dto;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Scheduledflight 
{
	@Id
	@Column(name="flight_Id")
	int flightId;
	@Column(name="source_airport")
	String sourceAirport;
	@Column(name="destinantion_airport")
	String destinationAirport;
	@Column(name="arrival_date_time")
	String arrivalDateTime;
	@Column(name="destination_date_time")
	String departureDateTime;
	public Scheduledflight() {
	}
	public Scheduledflight(int flightId, String sourceAirport, String destinationAirport, String arrivalDateTime,
			String departureDateTime) {
		this.flightId = flightId;
		this.sourceAirport = sourceAirport;
		this.destinationAirport = destinationAirport;
		this.arrivalDateTime = arrivalDateTime;
		this.departureDateTime = departureDateTime;
	}
	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
	public String getSourceAirport() {
		return sourceAirport;
	}
	public void setSourceAirport(String sourceAirport) {
		this.sourceAirport = sourceAirport;
	}
	public String getDestinationAirport() {
		return destinationAirport;
	}
	public void setDestinationAirport(String destinationAirport) {
		this.destinationAirport = destinationAirport;
	}
	public String getArrivalDateTime() {
		return arrivalDateTime;
	}
	public void setArrivalDateTime(String arrivalDateTime) {
		this.arrivalDateTime = arrivalDateTime;
	}
	public String getDepartureDateTime() {
		return departureDateTime;
	}
	public void setDepartureDateTime(String departureDateTime) {
		this.departureDateTime = departureDateTime;
	}
}
