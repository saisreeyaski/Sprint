package com.cg.anurag.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.anurag.dto.Scheduledflight;
import com.cg.anurag.service.ScheduledflightService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ScheduledflightController
{
	@Autowired
	ScheduledflightService scheduleService;
	public void setScheduleService(ScheduledflightService scheduleService)
	{
		this.scheduleService=scheduleService;
	}
	@GetMapping("/getScheduledflight")
	   public List<Scheduledflight> getScheduledFlight()
	   {
		   return scheduleService.getScheduledflight();
	   }

}
